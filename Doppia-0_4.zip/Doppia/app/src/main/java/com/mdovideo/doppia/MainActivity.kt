package com.mdovideo.doppia

import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.text.InputType
import android.text.Spannable
import android.text.SpannableString
import android.text.method.DigitsKeyListener
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.button.MaterialButton
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Pulsante REC stile Sony: anello bianco con pallino rosso; quadrato rosso mentre registra. */
class RecButton(ctx: Context) : View(ctx) {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = ctx.dp(2).toFloat()
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE53935.toInt() }
    var recording = false
        set(v) { field = v; invalidate() }
    var pending = false
        set(v) { field = v; alpha = if (v) 0.45f else 1f }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = width / 2f - ring.strokeWidth
        c.drawCircle(cx, cy, r, ring)
        if (recording) {
            val h = r * 0.5f
            c.drawRoundRect(cx - h, cy - h, cx + h, cy + h, h * 0.25f, h * 0.25f, fill)
        } else {
            c.drawCircle(cx, cy, r * 0.68f, fill)
        }
    }
}

/** Istogramma della luminanza (64 barre). */
class HistView(ctx: Context) : View(ctx) {
    var bins: IntArray? = null
        set(v) { field = v; invalidate() }
    private val barP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCCE8EDF3.toInt() }
    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x990B0F15.toInt() }

    override fun onDraw(c: Canvas) {
        val b = bins ?: return
        val r = dp(8).toFloat()
        c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, bgP)
        var mx = 1
        for (v in b) if (v > mx) mx = v
        val pad = dp(5).toFloat()
        val bw = (width - 2 * pad) / b.size
        val hh = height - 2 * pad
        for (i in b.indices) {
            val f = Math.sqrt(b[i].toDouble() / mx).toFloat()
            val x = pad + i * bw
            c.drawRect(x, pad + hh * (1f - f), x + bw * 0.85f, pad + hh, barP)
        }
    }
}

/** Esposimetro come il "M.M." Sony: scala da -3 a +3 EV con indicatore (stimato dall'immagine). */
class MeterView(ctx: Context) : View(ctx) {
    var ev = 0f
        set(v) { field = v; invalidate() }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.MUTED; strokeWidth = ctx.dp(1).toFloat() }
    private val zero = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = ctx.dp(2).toFloat() }
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Pal.TEXT
        textSize = ctx.dp(12).toFloat()
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Pal.MUTED
        textSize = ctx.dp(9).toFloat()
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = dp(14).toFloat()
        val x0 = pad
        val x1 = w - pad
        val yl = h * 0.60f
        for (k in -9..9) {
            val x = x0 + (k + 9) / 18f * (x1 - x0)
            val big = k % 3 == 0
            val th = dp(if (big) 8 else 4).toFloat()
            c.drawLine(x, yl - th, x, yl, if (k == 0) zero else tick)
        }
        c.drawText("-3", x0, yl + dp(11), label)
        c.drawText("0", (x0 + x1) / 2f, yl + dp(11), label)
        c.drawText("+3", x1, yl + dp(11), label)
        val e = ev.coerceIn(-3f, 3f)
        val xm = x0 + (e + 3f) / 6f * (x1 - x0)
        mark.color = if (Math.abs(ev) > 2f) 0xFFE53935.toInt() else Pal.MID
        val p = Path()
        p.moveTo(xm, yl + dp(1))
        p.lineTo(xm - dp(5), yl - dp(9))
        p.lineTo(xm + dp(5), yl - dp(9))
        p.close()
        c.drawPath(p, mark)
        c.drawText(String.format(Locale.ROOT, "%+.1f EV", ev), w / 2f, dp(11).toFloat(), txt)
    }
}

/** Griglia dei terzi, allineata all'immagine (non al riquadro). */
class GridView(ctx: Context) : View(ctx) {
    var aspect = 16f / 9f
    private val p = Paint().apply { color = 0x99FFFFFF.toInt(); strokeWidth = ctx.dp(1).toFloat() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        var iw = w
        var ih = w / aspect
        if (ih > h) { ih = h; iw = h * aspect }
        val l = (w - iw) / 2f
        val t = (h - ih) / 2f
        for (k in 1..2) {
            c.drawLine(l + iw * k / 3f, t, l + iw * k / 3f, t + ih, p)
            c.drawLine(l, t + ih * k / 3f, l + iw, t + ih * k / 3f, p)
        }
    }
}

/** Un riquadro con il live di una camera, in stile monitor Sony: REC, otturatore / diaframma / ISO, esposimetro, istogramma. */
class Tile(ctx: Context, private val label: String, private val accent: Int) : FrameLayout(ctx) {
    private val img = ImageView(ctx)
    private val zebraImg = ImageView(ctx)
    private val peakImg = ImageView(ctx)
    private val gridV = GridView(ctx)
    private val tag = TextView(ctx)
    private val lag = TextView(ctx)
    private val empty = TextView(ctx)

    private val recPill = TextView(ctx)
    private val recBtn = RecButton(ctx)
    private val bar = LinearLayout(ctx)
    private val meterBox = LinearLayout(ctx)
    private val meterV = MeterView(ctx)
    private val histV = HistView(ctx)
    private val picker = HorizontalScrollView(ctx)
    private val pickerRow = LinearLayout(ctx)
    private val chipBox = HashMap<Int, LinearLayout>()
    private val chipVal = HashMap<Int, TextView>()
    private val chipCodes = intArrayOf(SonyProps.SHUTTER, SonyProps.APERTURE, SonyProps.ISO)
    private val pickerItems = ArrayList<Pair<Long, TextView>>()
    private var props: Map<Int, Prop> = emptyMap()
    private var pickerCode = 0
    private var recStart = 0L
    private var evSmooth = 0f
    private val borderRed = GradientDrawable().apply {
        setColor(0)
        setStroke(ctx.dp(4), 0xFFE53935.toInt())
        cornerRadius = ctx.dp(22).toFloat()
    }

    /** True se la camera sta registrando (letto dalla camera, mai ipotizzato). */
    var recording = false
        private set
    var onRec: (() -> Unit)? = null
    var onPick: ((Prop, Long) -> Unit)? = null

    private val ticker = object : Runnable {
        override fun run() {
            if (!recording) return
            val sec = ((SystemClock.elapsedRealtime() - recStart) / 1000).toInt()
            val dot = if (sec % 2 == 0) "●" else "○"
            recPill.text = String.format(Locale.ROOT, "%s REC  %02d:%02d:%02d", dot, sec / 3600, (sec / 60) % 60, sec % 60)
            postDelayed(this, 500)
        }
    }

    private fun full() = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

    private fun divider(): View {
        val v = View(context)
        v.setBackgroundColor(Pal.LINE)
        val lp = LinearLayout.LayoutParams(dp(1), dp(30))
        lp.setMargins(dp(6), 0, dp(6), 0)
        v.layoutParams = lp
        return v
    }

    init {
        background = roundBg(Pal.SURFACE, 22, ctx)
        clipToOutline = true
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        addView(img, full())
        zebraImg.scaleType = ImageView.ScaleType.FIT_CENTER
        zebraImg.visibility = View.GONE
        addView(zebraImg, full())
        peakImg.scaleType = ImageView.ScaleType.FIT_CENTER
        peakImg.visibility = View.GONE
        addView(peakImg, full())
        gridV.visibility = View.GONE
        addView(gridV, full())

        empty.setTextColor(Pal.MUTED)
        empty.textSize = 15f
        empty.gravity = Gravity.CENTER
        empty.text = "Nessun segnale"
        addView(empty, full())

        tag.setTextColor(Pal.TEXT)
        tag.textSize = 13f
        tag.typeface = Typeface.DEFAULT_BOLD
        tag.setPadding(dp(10), dp(5), dp(10), dp(5))
        tag.background = roundBg(0xCC0B0F15.toInt(), 12, ctx)
        tag.text = label
        val tp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tp.gravity = Gravity.TOP or Gravity.START
        tp.setMargins(dp(12), dp(12), 0, 0)
        addView(tag, tp)

        lag.setTextColor(Pal.TEXT)
        lag.textSize = 12f
        lag.typeface = Typeface.MONOSPACE
        lag.setPadding(dp(10), dp(4), dp(10), dp(4))
        lag.background = roundBg(0xCC0B0F15.toInt(), 14, ctx)
        lag.visibility = View.GONE
        val lp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.TOP or Gravity.END
        lp.setMargins(0, dp(12), dp(12), 0)
        addView(lag, lp)

        // Pillola REC con il tempo, in alto al centro
        recPill.setTextColor(Color.WHITE)
        recPill.textSize = 14f
        recPill.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        recPill.setPadding(dp(14), dp(6), dp(14), dp(6))
        recPill.background = roundBg(0xE6C62828.toInt(), 16, ctx)
        recPill.visibility = View.GONE
        val rp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        rp.topMargin = dp(12)
        addView(recPill, rp)

        // Istogramma in basso a sinistra
        histV.visibility = View.GONE
        val hp = LayoutParams(dp(120), dp(60))
        hp.gravity = Gravity.BOTTOM or Gravity.START
        hp.setMargins(dp(12), 0, 0, dp(12))
        addView(histV, hp)

        // Barra monitor in basso: REC | otturatore diaframma ISO | esposimetro
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = roundBg(0xD90B0F15.toInt(), 18, ctx)
        bar.setPadding(dp(8), dp(5), dp(8), dp(5))
        bar.visibility = View.GONE

        recBtn.setOnClickListener {
            recBtn.pending = true
            postDelayed({ recBtn.pending = false }, 7000)
            onRec?.invoke()
        }
        bar.addView(recBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
        bar.addView(divider())

        val titles = arrayOf("SHUTTER", "IRIS", "ISO")
        for (k in chipCodes.indices) {
            val code = chipCodes[k]
            val box = LinearLayout(ctx)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            box.setPadding(dp(12), dp(3), dp(12), dp(3))
            val t = TextView(ctx)
            t.text = titles[k]
            t.textSize = 9f
            t.setTextColor(Pal.MUTED)
            t.gravity = Gravity.CENTER
            val v = TextView(ctx)
            v.text = "—"
            v.textSize = 19f
            v.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            v.setTextColor(Pal.MUTED)
            v.gravity = Gravity.CENTER
            box.addView(t)
            box.addView(v)
            box.setOnClickListener { togglePicker(code) }
            bar.addView(box)
            chipBox[code] = box
            chipVal[code] = v
        }

        meterBox.orientation = LinearLayout.HORIZONTAL
        meterBox.gravity = Gravity.CENTER_VERTICAL
        meterBox.visibility = View.GONE
        meterBox.addView(divider())
        meterBox.addView(meterV, LinearLayout.LayoutParams(dp(150), dp(38)))
        bar.addView(meterBox)

        val barLp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        barLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        barLp.bottomMargin = dp(12)
        addView(bar, barLp)

        // Selettore valori sopra la barra (scorre in orizzontale, tocca per scegliere)
        pickerRow.orientation = LinearLayout.HORIZONTAL
        pickerRow.setPadding(dp(8), dp(4), dp(8), dp(4))
        picker.isHorizontalScrollBarEnabled = false
        picker.addView(pickerRow)
        picker.background = roundBg(0xE60B0F15.toInt(), 16, ctx)
        picker.visibility = View.GONE
        val pkLp = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        pkLp.gravity = Gravity.BOTTOM
        pkLp.setMargins(dp(12), 0, dp(12), dp(88))
        addView(picker, pkLp)
    }

    fun setFrame(b: Bitmap, ms: Int, a: Analysis?) {
        img.setImageBitmap(b)
        empty.visibility = View.GONE
        lag.visibility = View.VISIBLE
        val s = SpannableString("● $ms ms")
        s.setSpan(ForegroundColorSpan(lagColor(ms)), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        lag.text = s

        gridV.aspect = b.width.toFloat() / b.height
        gridV.visibility = if (Monitor.grid) View.VISIBLE else View.GONE
        gridV.invalidate()

        val z = a?.zebra
        zebraImg.setImageBitmap(z)
        zebraImg.visibility = if (z != null) View.VISIBLE else View.GONE
        val pk = a?.peaking
        peakImg.setImageBitmap(pk)
        peakImg.visibility = if (pk != null) View.VISIBLE else View.GONE

        histV.bins = a?.hist
        histV.visibility = if (a?.hist != null) View.VISIBLE else View.GONE

        if (a != null && Monitor.meter) {
            evSmooth = evSmooth * 0.8f + a.ev * 0.2f
            meterV.ev = evSmooth
            meterBox.visibility = View.VISIBLE
        } else {
            meterBox.visibility = View.GONE
        }
    }

    fun setState(st: CamState) {
        when (st) {
            CamState.IDLE -> clear("Nessun segnale")
            CamState.CONNECTING -> clear("Mi collego…")
            CamState.WAITING -> clear("In attesa del live view…")
            CamState.ERROR -> clear("Collegamento non riuscito, guarda il log")
            CamState.LIVE -> {}
        }
    }

    /** Aggiorna valori, stato REC e pulsanti con la tabella proprieta' appena letta dalla camera. */
    fun setProps(m: Map<Int, Prop>) {
        props = m
        bar.visibility = View.VISIBLE
        for (code in chipCodes) {
            val p = m[code]
            val tv = chipVal[code]!!
            tv.text = if (p == null) "—" else SonyProps.fmt(code, p.current)
            tv.setTextColor(if (p != null && p.settable) Pal.TEXT else Pal.MUTED)
            chipBox[code]!!.background = if (pickerCode == code) roundBg(0x33FFC107.toInt(), 12, context) else null
        }
        if (pickerCode != 0) {
            val p = m[pickerCode]
            if (p == null || !p.settable) closePicker() else highlight(p.current, false)
        }
        val r = (m[SonyProps.REC_STATE]?.current ?: 0L) != 0L
        if (r != recording) {
            recording = r
            recBtn.pending = false
            recBtn.recording = r
            foreground = if (r) borderRed else null
            if (r) {
                recStart = SystemClock.elapsedRealtime()
                recPill.visibility = View.VISIBLE
                removeCallbacks(ticker)
                post(ticker)
            } else {
                recPill.visibility = View.GONE
                removeCallbacks(ticker)
            }
        }
    }

    private fun togglePicker(code: Int) {
        if (pickerCode == code) { closePicker(); return }
        val p = props[code] ?: return
        if (!p.settable || p.options.isEmpty()) return
        pickerCode = code
        pickerRow.removeAllViews()
        pickerItems.clear()
        for (v in p.options) {
            val t = TextView(context)
            t.text = SonyProps.fmt(code, v)
            t.textSize = 17f
            t.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            t.setPadding(dp(14), dp(8), dp(14), dp(8))
            t.setOnClickListener { onPick?.invoke(p, v) }
            pickerRow.addView(t)
            pickerItems.add(v to t)
        }
        picker.visibility = View.VISIBLE
        for (c in chipCodes) chipBox[c]?.background = if (c == code) roundBg(0x33FFC107.toInt(), 12, context) else null
        highlight(p.current, true)
    }

    private fun closePicker() {
        pickerCode = 0
        picker.visibility = View.GONE
        for (c in chipCodes) chipBox[c]?.background = null
    }

    private fun highlight(cur: Long, scroll: Boolean) {
        var curView: TextView? = null
        for ((v, t) in pickerItems) {
            val on = v == cur
            t.setTextColor(if (on) Pal.MID else Pal.TEXT)
            t.background = if (on) roundBg(0x33FFC107.toInt(), 10, context) else null
            if (on) curView = t
        }
        if (scroll && curView != null) {
            val t = curView
            picker.post { picker.scrollTo(maxOf(0, t.left - picker.width / 2 + t.width / 2), 0) }
        }
    }

    private fun clear(text: String) {
        img.setImageDrawable(null)
        zebraImg.visibility = View.GONE
        peakImg.visibility = View.GONE
        gridV.visibility = View.GONE
        histV.visibility = View.GONE
        meterBox.visibility = View.GONE
        lag.visibility = View.GONE
        empty.text = text
        empty.visibility = View.VISIBLE
        closePicker()
        bar.visibility = View.GONE
        recPill.visibility = View.GONE
        foreground = null
        recording = false
        recBtn.recording = false
        recBtn.pending = false
        removeCallbacks(ticker)
    }
}

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("doppia", MODE_PRIVATE) }
    private val cams = arrayOfNulls<SonyCam>(2)
    private lateinit var tiles: Array<Tile>
    private lateinit var fields: Array<EditText>
    private lateinit var buttons: Array<MaterialButton>
    private lateinit var status: TextView
    private lateinit var logText: TextView
    private lateinit var logScroll: ScrollView
    private val liveNow = BooleanArray(2)
    private val lines = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.ROOT)
    private var solo = -1
    private lateinit var tilesRow: LinearLayout
    private var settingsDlg: Dialog? = null
    private var settingsParams: LinearLayout? = null
    private var settingsSig = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Monitor.load(prefs)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Pal.BG)
        root.fitsSystemWindows = true
        root.setPadding(dp(14), dp(10), dp(14), dp(12))

        // Barra in alto
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Doppia"
        title.setTextColor(Pal.TEXT)
        title.textSize = 22f
        title.typeface = Typeface.DEFAULT_BOLD
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        status = TextView(this)
        status.setTextColor(Pal.MUTED)
        status.textSize = 12f
        status.typeface = Typeface.MONOSPACE
        status.setPadding(dp(12), dp(5), dp(12), dp(5))
        status.background = roundBg(Pal.CARD, 14, this)
        bar.addView(status)
        val recAllBtn = pillButton("REC A+B")
        recAllBtn.backgroundTintList = ColorStateList.valueOf(0xFFB71C1C.toInt())
        recAllBtn.setOnClickListener { recBoth() }
        val setBtn = pillButton("Impostazioni")
        setBtn.setOnClickListener { showSettings() }
        val scanBtn = pillButton("Cerca camere")
        scanBtn.setOnClickListener { scan() }
        val logBtn = pillButton("Log")
        logBtn.setOnClickListener {
            logScroll.visibility = if (logScroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        bar.addView(recAllBtn, spaced(10))
        bar.addView(setBtn, spaced(6))
        bar.addView(scanBtn, spaced(6))
        bar.addView(logBtn, spaced(6))
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Area dei due riquadri, con il log sopra
        val stage = FrameLayout(this)
        tilesRow = LinearLayout(this)
        tilesRow.orientation = LinearLayout.HORIZONTAL
        tiles = arrayOf(Tile(this, "Camera A", Pal.COLD), Tile(this, "Camera B", Pal.HOT))
        for (i in 0..1) {
            val t = tiles[i]
            t.onRec = { cams[i]?.toggleRec() }
            t.onPick = { p, v -> cams[i]?.setProp(p, v) }
            Springs.pressable(t, 0.985f)
            t.setOnClickListener {
                solo = if (solo == i) -1 else i
                applyLayout()
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            if (i == 1) lp.leftMargin = dp(10)
            tilesRow.addView(t, lp)
        }
        stage.addView(tilesRow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        logText = TextView(this)
        logText.setTextColor(Pal.TEXT)
        logText.textSize = 11.5f
        logText.typeface = Typeface.MONOSPACE
        logText.setPadding(dp(14), dp(12), dp(14), dp(12))
        logScroll = ScrollView(this)
        logScroll.background = roundBg(0xE60B0F15.toInt(), 22, this)
        logScroll.addView(logText)
        logScroll.visibility = View.GONE
        stage.addView(logScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val sp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        sp.topMargin = dp(10)
        root.addView(stage, sp)

        // Righe di collegamento
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        fields = Array(2) { EditText(this) }
        buttons = Array(2) { pillButton("Connetti") }
        for (i in 0..1) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = rowBg(true, true, Pal.CARD)
            row.setPadding(dp(10), dp(8), dp(10), dp(8))

            val av = TextView(this)
            av.text = if (i == 0) "A" else "B"
            av.gravity = Gravity.CENTER
            av.setTextColor(Pal.BG)
            av.typeface = Typeface.DEFAULT_BOLD
            av.background = roundBg(if (i == 0) Pal.COLD else Pal.HOT, 20, this)
            row.addView(av, LinearLayout.LayoutParams(dp(40), dp(40)))

            val f = fields[i]
            f.hint = "indirizzo IP, es. 192.168.43.21"
            f.setHintTextColor(Pal.MUTED)
            f.setTextColor(Pal.TEXT)
            f.textSize = 14f
            f.typeface = Typeface.MONOSPACE
            f.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            f.keyListener = DigitsKeyListener.getInstance("0123456789.")
            f.setSingleLine(true)
            f.setBackgroundColor(0)
            f.setPadding(dp(12), dp(8), dp(12), dp(8))
            f.setText(prefs.getString("ip$i", "") ?: "")
            val flp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            row.addView(f, flp)

            val b = buttons[i]
            b.setOnClickListener { toggle(i) }
            row.addView(b)

            val rlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (i == 1) rlp.leftMargin = dp(10)
            bottom.addView(row, rlp)
        }
        val bp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bp.topMargin = dp(10)
        root.addView(bottom, bp)

        setContentView(root)
        refreshStatus()
        addLog("Doppia 0.4: live, REC, esposizione, zebra, peaking, istogramma.")
        val mine = localIpv4()
        addLog(if (mine.isEmpty()) "Il tablet non è collegato a nessuna rete" else "Rete del tablet: ${mine.joinToString(", ")}")
    }

    override fun onDestroy() {
        for (i in 0..1) cams[i]?.stop()
        super.onDestroy()
    }

    private fun pillButton(text: String): MaterialButton {
        val b = MaterialButton(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 13f
        b.setTextColor(Pal.TEXT)
        b.backgroundTintList = ColorStateList.valueOf(Pal.LINE)
        b.cornerRadius = dp(20)
        b.insetTop = 0
        b.insetBottom = 0
        Springs.pressable(b)
        return b
    }

    private fun spaced(left: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.leftMargin = dp(left)
        return p
    }

    /** Avvia o ferma la registrazione su tutte le camere live: se una registra, ferma quelle che registrano. */
    private fun recBoth() {
        val live = (0..1).filter { cams[it] != null && liveNow[it] }
        if (live.isEmpty()) {
            addLog("REC: nessuna camera live")
            return
        }
        val anyRec = live.any { tiles[it].recording }
        for (i in live) if (tiles[i].recording == anyRec) cams[i]?.toggleRec()
    }

    private fun applyLayout() {
        for (j in 0..1) tiles[j].visibility = if (solo == -1 || solo == j) View.VISIBLE else View.GONE
    }

    private fun refreshStatus() {
        val n = liveNow.count { it }
        status.text = if (n == 0) "nessuna camera live" else "$n di 2 live"
    }

    // ---------- Impostazioni ----------

    private fun showSettings() {
        settingsDlg?.dismiss()
        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(18), dp(22), dp(18))
        scroll.addView(col)

        val head = TextView(this)
        head.text = "Impostazioni"
        head.setTextColor(Pal.TEXT)
        head.textSize = 20f
        head.typeface = Typeface.DEFAULT_BOLD
        col.addView(head)

        col.addView(sectionTitle("Monitor"))
        col.addView(toggleRow("Zebra", Monitor.zebra) { Monitor.zebra = it; Monitor.save(prefs) })
        val zl = listOf(70, 80, 90, 95, 100)
        col.addView(chooserRow("Livello zebra (%)", zl.map { it.toString() }, zl.indexOf(Monitor.zebraLevel).coerceAtLeast(0)) {
            Monitor.zebraLevel = zl[it]; Monitor.save(prefs)
        })
        col.addView(toggleRow("Focus peaking", Monitor.peaking) { Monitor.peaking = it; Monitor.save(prefs) })
        val pc = listOf(0xFFFF1744.toInt(), 0xFFFFEB3B.toInt(), 0xFFFFFFFF.toInt(), 0xFF69F0AE.toInt())
        col.addView(chooserRow("Colore peaking", listOf("Rosso", "Giallo", "Bianco", "Verde"), pc.indexOf(Monitor.peakColor).coerceAtLeast(0)) {
            Monitor.peakColor = pc[it]; Monitor.save(prefs)
        })
        col.addView(toggleRow("Griglia dei terzi", Monitor.grid) { Monitor.grid = it; Monitor.save(prefs) })
        col.addView(toggleRow("Istogramma", Monitor.histogram) { Monitor.histogram = it; Monitor.save(prefs) })
        col.addView(toggleRow("Esposimetro (stimato dall'immagine)", Monitor.meter) { Monitor.meter = it; Monitor.save(prefs) })

        val params = LinearLayout(this)
        params.orientation = LinearLayout.VERTICAL
        col.addView(params)
        settingsParams = params
        fillParams(params)
        settingsSig = paramSig()

        col.addView(sectionTitle("Diagnostica"))
        val copy = pillButton("Copia log e proprietà delle camere")
        copy.setOnClickListener { copyDiagnostics() }
        col.addView(copy, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val close = pillButton("Chiudi")
        val cl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cl.topMargin = dp(18)
        cl.gravity = Gravity.END
        col.addView(close, cl)

        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dlg.setContentView(scroll)
        dlg.window?.setBackgroundDrawable(roundBg(Pal.SURFACE, 24, this))
        dlg.setOnDismissListener { settingsDlg = null; settingsParams = null }
        close.setOnClickListener { dlg.dismiss() }
        settingsDlg = dlg
        dlg.show()
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.6f).toInt(), (resources.displayMetrics.heightPixels * 0.85f).toInt())
    }

    private val paramCodes = intArrayOf(SonyProps.EXP_MODE, SonyProps.EXP_COMP, SonyProps.METERING, SonyProps.WB)
    private val paramNames = mapOf(
        SonyProps.EXP_MODE to "Modo esposizione",
        SonyProps.EXP_COMP to "Compensazione EV",
        SonyProps.METERING to "Misurazione luce",
        SonyProps.WB to "Bilanciamento bianco"
    )

    private fun paramSig(): String {
        val sb = StringBuilder()
        for (i in 0..1) {
            sb.append(if (liveNow[i]) 'L' else '-')
            val m = cams[i]?.props ?: continue
            for (c in paramCodes) sb.append(m[c]?.current).append(',').append(m[c]?.settable).append(';')
        }
        return sb.toString()
    }

    private fun refreshSettings() {
        val params = settingsParams ?: return
        val sig = paramSig()
        if (sig == settingsSig) return
        settingsSig = sig
        params.removeAllViews()
        fillParams(params)
    }

    private fun fillParams(container: LinearLayout) {
        var any = false
        for (i in 0..1) {
            val cam = cams[i]
            if (cam == null || !liveNow[i]) continue
            any = true
            container.addView(sectionTitle(if (i == 0) "Camera A" else "Camera B"))
            val m = cam.props
            var rows = 0
            for (code in paramCodes) {
                val p = m[code] ?: continue
                container.addView(stepperRow(paramNames[code] ?: "", cam, p))
                rows++
            }
            if (rows == 0) container.addView(note("La camera non espone parametri modificabili in questa modalità."))
        }
        if (!any) {
            container.addView(sectionTitle("Camere"))
            container.addView(note("Collega una camera per cambiare i suoi parametri."))
        }
    }

    private fun sectionTitle(text: String): TextView {
        val t = TextView(this)
        t.text = text.uppercase(Locale.ROOT)
        t.setTextColor(Pal.MID)
        t.textSize = 12f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(0, dp(18), 0, dp(6))
        return t
    }

    private fun note(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Pal.MUTED)
        t.textSize = 13f
        t.setPadding(0, dp(4), 0, dp(4))
        return t
    }

    private fun toggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val sw = SwitchCompat(this)
        sw.text = label
        sw.setTextColor(Pal.TEXT)
        sw.textSize = 15f
        sw.isChecked = checked
        sw.setPadding(0, dp(8), 0, dp(8))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        return sw
    }

    private fun chooserRow(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(6), 0, dp(6))
        val l = TextView(this)
        l.text = label
        l.setTextColor(Pal.TEXT)
        l.textSize = 15f
        row.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val pills = ArrayList<TextView>()
        fun paint(sel: Int) {
            for ((k, t) in pills.withIndex()) {
                val on = k == sel
                t.setTextColor(if (on) Pal.MID else Pal.TEXT)
                t.background = roundBg(if (on) 0x33FFC107 else Pal.LINE, 14, this)
            }
        }
        for ((k, o) in options.withIndex()) {
            val t = TextView(this)
            t.text = o
            t.textSize = 14f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setPadding(dp(14), dp(7), dp(14), dp(7))
            t.setOnClickListener { paint(k); onSelect(k) }
            pills.add(t)
            row.addView(t, spaced(6))
        }
        paint(selected)
        return row
    }

    private fun stepperRow(label: String, cam: SonyCam, p: Prop): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(6), 0, dp(6))
        val l = TextView(this)
        l.text = label
        l.setTextColor(Pal.TEXT)
        l.textSize = 15f
        row.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val can = p.settable && p.options.isNotEmpty()
        val idx = p.options.indexOf(p.current)
        fun step(d: Int) {
            if (!can) return
            val n = (if (idx < 0) 0 else idx + d).coerceIn(0, p.options.size - 1)
            cam.setProp(p, p.options[n])
        }
        val minus = pillButton("‹")
        val plus = pillButton("›")
        minus.setOnClickListener { step(-1) }
        plus.setOnClickListener { step(1) }
        minus.isEnabled = can
        plus.isEnabled = can
        val v = TextView(this)
        v.text = SonyProps.fmt(p.code, p.current)
        v.setTextColor(if (can) Pal.TEXT else Pal.MUTED)
        v.textSize = 16f
        v.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        v.gravity = Gravity.CENTER
        row.addView(minus)
        row.addView(v, LinearLayout.LayoutParams(dp(130), ViewGroup.LayoutParams.WRAP_CONTENT))
        row.addView(plus)
        return row
    }

    private fun copyDiagnostics() {
        val sb = StringBuilder()
        for (i in 0..1) {
            val m = cams[i]?.props ?: continue
            sb.append("== Camera ").append(if (i == 0) "A" else "B").append(" (").append(m.size).append(" proprietà)\n")
            for (p in m.values) {
                sb.append(String.format(Locale.ROOT, "%04X t=%X gs=%d en=%d cur=%X opts=%d",
                    p.code, p.type, p.getSet, p.enabledFlag, p.current, p.options.size))
                if (p.options.isNotEmpty() && p.options.size <= 40) {
                    sb.append(" [").append(p.options.joinToString(",") { java.lang.Long.toHexString(it) }).append(']')
                }
                sb.append('\n')
            }
        }
        sb.append("== Log\n").append(lines.joinToString("\n"))
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Doppia diagnostica", sb.toString()))
        addLog("Diagnostica copiata negli appunti (${sb.length} caratteri)")
    }

    // ---------- Collegamento ----------

    private fun toggle(i: Int) {
        val running = cams[i]
        if (running != null) {
            running.stop()
            cams[i] = null
            return
        }
        val ip = fields[i].text.toString().trim()
        if (!Regex("""\d{1,3}(\.\d{1,3}){3}""").matches(ip)) {
            addLog("Camera ${if (i == 0) "A" else "B"}: scrivi un indirizzo IP valido")
            return
        }
        prefs.edit().putString("ip$i", ip).apply()
        val cam = SonyCam(
            ip, guid(), if (i == 0) "A" else "B",
            { s -> addLog(s) },
            { st -> runOnUiThread { onState(i, st) } },
            { bmp, ms ->
                val a = Monitor.analyze(bmp)
                runOnUiThread { tiles[i].setFrame(bmp, ms, a) }
            },
            { m -> runOnUiThread { tiles[i].setProps(m); refreshSettings() } }
        )
        cams[i] = cam
        cam.start()
    }

    private fun onState(i: Int, st: CamState) {
        tiles[i].setState(st)
        liveNow[i] = st == CamState.LIVE
        buttons[i].text = when (st) {
            CamState.IDLE -> "Connetti"
            CamState.ERROR -> "Riprova"
            else -> "Stop"
        }
        if (st == CamState.ERROR) cams[i] = null
        refreshStatus()
        refreshSettings()
    }

    private fun scan() {
        addLog("Cerco camere sulla rete…")
        Thread {
            val found = scanPtpHosts { s -> addLog(s) }
            runOnUiThread {
                if (found.isEmpty()) {
                    addLog("Nessuna camera trovata. Controlla che siano accese, con il Wi-Fi attivo e sulla stessa rete del tablet.")
                } else {
                    addLog("Trovate: ${found.joinToString(", ")}")
                    for (h in found) {
                        if (fields.any { it.text.toString().trim() == h }) continue
                        val empty = fields.firstOrNull { it.text.toString().trim().isEmpty() } ?: break
                        empty.setText(h)
                    }
                }
            }
        }.start()
    }

    private fun guid(): ByteArray {
        var hex = prefs.getString("guid", null)
        if (hex == null || hex.length != 32) {
            val b = ByteArray(16)
            java.security.SecureRandom().nextBytes(b)
            hex = b.joinToString("") { String.format(Locale.ROOT, "%02x", it) }
            prefs.edit().putString("guid", hex).apply()
        }
        return ByteArray(16) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }

    private fun addLog(s: String) {
        runOnUiThread {
            lines.addLast(clock.format(Date()) + "  " + s)
            while (lines.size > 300) lines.removeFirst()
            logText.text = lines.joinToString("\n")
            logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }
}
